var Blue = Disc;
var Red = Disc;
// xy = Red | x1y1 = Blue
var x = 575;
var y = 200;
var x1 = 25;
var y1= 200;
var Pspd = 5
var Hockey 

function setup() { 
  createCanvas(600,400);
  Hockey = new Puck(300,200,38,38);
}

function draw() { 
  background(220);
  
  fill(220);
  ellipse(width/2,200,100,100);
  line(width/2,0,width/2,400);
  fill('red');
  rect(-250,100,300,200);
  fill('blue');
  rect(550,100,300,200);
  Blue(x1,y1,50,50,'blue');
	Hockey.display();
  Hockey.collide(x,y);
  Hockey.collide(x1,y1);
  Hockey.move();
  Red(x,y,50,50,'red');  
  
    if (keyIsDown(LEFT_ARROW)) {
   if (x>width/2+25) x = x-Pspd;
  }
   if (keyIsDown(RIGHT_ARROW)) {
    if (x<width-Pspd) x= x+Pspd;
  }
   if (keyIsDown(UP_ARROW)) {
   if (y>Pspd) y = y-Pspd;
  }
    
   if (keyIsDown(DOWN_ARROW)) {
    if (y<height) y = y+Pspd;
}
  if (keyIsDown(65)) {//left
    if (x1> Pspd) x1 = x1-Pspd;
  }
   if (keyIsDown(68)) {//right
    if (x1<width/2-25) x1= x1+Pspd;
  }
   if (keyIsDown (87)) {//up
    if (y1> Pspd) y1 = y1-Pspd;
  }
   if (keyIsDown (83)) {//down
    if (y1<height)y1 = y1+Pspd;
	}
  
}



  function Disc(x,y,d,d,r) {
    push();
    fill(r);
    ellipse(x,y,d,d);
    pop();
}

	function Puck(x_,y_,r,r){
    this.X = x_;
    this.Y = y_;
    this.mass = 15;
		this.velocityX = 3;
		this.velocityY = 3;
		this.maxSpeed = 10;
		this.frictionX = 0.997;
		this.frictionY = 0.997;
		this.acceleration = 1;
    this.radius = r;
    this.clr = '#000000';
    
    this.display = function(){
      push();
      fill(this.clr);
      ellipse(this.X,this.Y,this.radius,this.radius);
      pop(); 
    }
    
    this.move = function(){
       this.X = this.X + this.velocityX;
      this.Y = this.Y + this.velocityY;
      if (this.Y >= height-this.radius/2 || this.Y <= 0+this.radius/2){
        this.velocityY = this.velocityY* -1;
      }
      
      if (this.X >= width-this.radius/2 || this.X <= 0+this.radius/2){
        this.velocityX = this.velocityX* -1;
      }

  }
    
    this.collide= function(x,y){
      var d = dist(this.X,this.Y,x,y);
      if (d < this.radius){
        this.velocityX = this.velocityX* -1;
        this.velocityY = this.velocityY* -1;
      }
      
    }
  }
    
  
